export interface Book {
    title: string;
    author: string;
    available: boolean;
  }
  